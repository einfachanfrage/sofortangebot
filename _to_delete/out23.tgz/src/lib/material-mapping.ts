// Ordnet einer Arbeits-Position die passende Material-Position zu.
// z.B. "Wandflächen streichen" → { name: "Wandfarbe", unit: "m²" }.
// Der Nutzer trägt im Untertitel das konkrete Produkt/Farbe ein.
//
// Menge der Material-Position = Menge der Arbeits-Position (gleiche Fläche/Anzahl).
// Preis: aus der Preisdatenbank wenn vorhanden, sonst 0 € (Entscheidung des Nutzers).

export interface MaterialVorschlag {
  name: string
  unit: string
}

interface Regel { test: RegExp; material: MaterialVorschlag }

// ── PM-030-B / PM-025 (Prüfmeister, 07.09.2026) ──────────────────────────
//
// „Dachschrägen streichen 2x" hatte weder Untertitel noch Materialzeile,
// „Kniestockwände streichen 2x" beides. Für 18 m² fehlte damit das Material.
//
// Sein Befund dahinter trifft den Kern: An einem Tag sind sechs neue
// Positionsarten entstanden — Fischgrät, Diagonal-Aufpreis, Leibungen,
// Fensterbänke, Dachschrägen, Sockelleisten streichen. **Jede neue
// Positionsart braucht drei Dinge: eine Menge, einen Katalogpreis und ein
// Material.** Mitgewachsen war nur das erste.
//
// Beim Nachziehen ist ein eigener Fehler von heute aufgefallen: „Aufpreis
// Diagonalverlegung Vinyl" trifft das Muster `verleg.*vinyl` und hätte das
// Belagsmaterial ein ZWEITES Mal erzeugt — der Belag steckt schon in der
// Verlegeposition. Aufpreiszeilen sind reine Arbeitszuschläge und bekommen
// deshalb ausdrücklich kein Material.
const AUFPREIS = /^aufpreis\b/i

const REGELN: Regel[] = [
  // — Maler —
  { test: /wandfläche(n)?\s*streich|wände\s*streich/i, material: { name: 'Wandfarbe', unit: 'm²' } },
  { test: /fassadenfläche(n)?\s*streich|fassade\s*streich/i, material: { name: 'Fassadenfarbe', unit: 'm²' } },
  // Eine Dachschräge wird mit derselben Wandfarbe gestrichen wie der
  // Kniestock daneben — dieselbe Farbe, dieselbe Fläche, dieselbe Zeile.
  { test: /dachschräge(n)?\s*streich|dachfläche(n)?\s*streich/i, material: { name: 'Wandfarbe', unit: 'm²' } },
  // Die Innenleibung eines Fensters gehört zur Wand und wird mit ihr
  // gestrichen (DIN 18363 5.2.3 rechnet sie nur getrennt ab).
  { test: /leibung|laibung/i, material: { name: 'Wandfarbe', unit: 'm²' } },
  { test: /decken?(fläche)?\s*streich|decke\s*streich/i, material: { name: 'Deckenfarbe', unit: 'm²' } },
  { test: /grundier|voranstrich|tiefengrund/i, material: { name: 'Tiefengrund / Grundierung', unit: 'm²' } },
  { test: /spachtel|glätt/i, material: { name: 'Spachtelmasse', unit: 'm²' } },
  { test: /(raufaser|vlies|tapete)\s*(aufzieh|tapezier|aufbring)|tapezieren/i, material: { name: 'Tapete / Raufaser', unit: 'm²' } },
  { test: /stuckleisten\s*montier/i, material: { name: 'Stuckleisten (Material)', unit: 'lfdm' } },
  // — Lackieren —
  { test: /türen?\s*lackier|türzarge/i, material: { name: 'Lack (Türen)', unit: 'Stück' } },
  { test: /fenster.*(lackier|anstrich|öl)/i, material: { name: 'Lack (Fenster)', unit: 'Stück' } },
  { test: /heizkörper\s*(lackier|streich)/i, material: { name: 'Heizkörperlack', unit: 'Stück' } },
  { test: /\blackier/i, material: { name: 'Lack', unit: 'Stück' } },
  // — Boden — (Belag aus dem Titel)
  { test: /klick-?vinyl.*verleg|verleg.*klick-?vinyl/i, material: { name: 'Klick-Vinyl (Material)', unit: 'm²' } },
  // PM-025: „Designbelag im Fischgrätmuster kleben" heißt nicht „verlegen"
  // und traf deshalb keine einzige Belagsregel.
  { test: /designbelag|designboden/i, material: { name: 'Vinyl / Designboden (Material)', unit: 'm²' } },
  { test: /v[ie]nyl.*verleg|verleg.*v[ie]nyl|designboden.*verleg/i, material: { name: 'Vinyl / Designboden (Material)', unit: 'm²' } },
  { test: /laminat.*verleg|verleg.*laminat/i, material: { name: 'Laminat (Material)', unit: 'm²' } },
  { test: /parkett.*verleg|verleg.*parkett|fertigparkett/i, material: { name: 'Parkett (Material)', unit: 'm²' } },
  { test: /kork.*verleg|verleg.*kork/i, material: { name: 'Kork (Material)', unit: 'm²' } },
  { test: /linoleum.*verleg|verleg.*linoleum/i, material: { name: 'Linoleum (Material)', unit: 'm²' } },
  { test: /teppich.*verleg|nadelvlies.*verleg/i, material: { name: 'Teppichboden (Material)', unit: 'm²' } },
  { test: /\bverleg/i, material: { name: 'Bodenbelag (Material)', unit: 'm²' } },
  { test: /sockelleisten\s*montier/i, material: { name: 'Sockelleisten (Material)', unit: 'lfdm' } },
  { test: /trittschall|dämmung/i, material: { name: 'Trittschalldämmung (Material)', unit: 'm²' } },
]

/** Passendes Material zur Arbeits-Position, oder null wenn kein Material anfällt. */
export function materialFuerPosition(titel: string): MaterialVorschlag | null {
  const t = titel ?? ''
  // Material-Positionen selbst bekommen kein weiteres Material
  if (/\(material\)|wandfarbe|deckenfarbe|fassadenfarbe|tiefengrund|spachtelmasse|heizkörperlack|\black\b/i.test(t)) return null
  // Aufpreiszeilen sind Arbeitszuschläge auf eine Position, die ihr Material
  // schon trägt — sonst steht der Belag zweimal im Angebot.
  if (AUFPREIS.test(t.trim())) return null
  for (const r of REGELN) {
    if (r.test.test(t)) return r.material
  }
  return null
}
