import type { ExtrahierteDaten } from './mengen/types'

export type Plan = 'starter' | 'pro'
export type AccountingSoftware =
  | 'lexoffice'
  | 'lexware'
  | 'sevdesk'
  | 'fastbill'
  | 'billomat'
  | 'papierkram'
  | 'easybill'
  | 'datev'
  | 'sage'
  | 'plancraft'
  | 'none'
export type QuoteStatus = 'draft' | 'sent' | 'accepted' | 'rejected' | 'in_bearbeitung' | 'archived'

export type EntwurfVerarbeitungStatus = 'ausstehend' | 'verarbeitung' | 'fertig' | 'fehler'
export type EntwurfAufnahmeTyp = 'sprache' | 'notiz' | 'foto'

export interface EntwurfAufnahme {
  id: string
  angebot_id: string
  typ: EntwurfAufnahmeTyp
  audio_url: string | null
  audio_dauer_sekunden: number | null
  transkript: string | null
  erkannte_positionen: ErkanntPosition[]
  verarbeitung_status: EntwurfVerarbeitungStatus
  notiz_text: string | null
  foto_url: string | null
  foto_beschreibung: string | null
  in_pdf: boolean
  erstellt_am: string
  geraet: string | null
  sortierung: number
  // CoS-002 Option 1 (docs/cos-002-architektur-vorschlag.md): gecachtes
  // Ergebnis der vollen ki-extrahieren-Extraktion, zusätzlich zur schnellen
  // Chip-Vorschau in erkannte_positionen — siehe VollExtraktionCache.
  // Optional statt Pflichtfeld, damit ältere Row-Lesestellen/Objekt-Literale
  // im Code nicht überall angepasst werden müssen.
  voll_extraktion?: VollExtraktionCache | null
  // für Signed URLs
  audio_signed_url?: string
  foto_signed_url?: string
}

export interface ErkanntPosition {
  titel: string
  menge: number
  einheit: string
  einzelpreis: number
  gesamtpreis: number
  erkannt: boolean
}

// CoS-002 Option 1 Schritt 1+2+3 (Head of Product Engineering, 2026-08-21,
// docs/design-check.md DC-030): Inhalt der neuen Spalte
// entwurf_aufnahmen.voll_extraktion. Zwei mögliche Formen, je nachdem, wie
// der Hintergrund-Aufruf in src/lib/volle-extraktion-cache.ts ausging:
// - Erfolg: `result` ist das ROHE ki-extrahieren-Ergebnis (für Schritt 3 —
//   der Geld-Pfad in /api/angebot-extrahieren führt es noch einmal durch
//   verarbeiteExtraktion, diesmal mit dem tatsächlichen combinedText/
//   antworten/basis_extraktion zum Zeitpunkt von "Entwurf erstellen", statt
//   selbst erneut ki-extrahieren aufzurufen). `positionen` ist zusätzlich
//   schon fertig durch dieselbe Pipeline gejagt (verarbeiteExtraktion,
//   src/lib/mengen/extraktion-pipeline.ts) — nur für die Karten-Vorschau
//   (Schritt 2), NICHT die Quelle für Schritt 3 (dort zählt `result`).
// - Fehlschlag (Rate-Limit, Netzwerk-/GPT-Fehler): `__fehlgeschlagen` markiert
//   das explizit, damit die Karte NICHT endlos auf ein Ergebnis wartet, das
//   nie kommt (siehe DC-030-Nachtrag zur Entwurf-erstellen-Gate-Anforderung).
export interface VollExtraktionCache {
  result?: ExtrahierteDaten
  positionen?: ErkanntPosition[]
  __fehlgeschlagen?: true
}

// CoS-002 Option 1 Schritt 3, Mehrfach-Aufnahmen-Fall (Head of Product
// Engineering, 2026-08-21, Sandys Auftrag "mach komplett rund, das auch
// noch schließen" — siehe src/lib/kombinierte-extraktion-cache.ts für die
// volle Begründung). Inhalt der neuen Spalte quotes.kombinierte_
// extraktion_cache: ein spekulativ VORAB berechnetes ki-extrahieren-
// Ergebnis für eine bestimmte Menge Aufnahmen (aufnahme_ids, sortiert).
// generiere-positionen nutzt `result` nur wieder, wenn aufnahme_ids exakt
// zur aktuell kombinierten Aufnahmen-Menge passt — bei jeder Abweichung
// (Menge geändert, Cache fehlt) unverändert der bisherige frische
// Kombi-Aufruf, kein Korrektheits-Risiko.
export interface KombinierteExtraktionCache {
  aufnahme_ids: string[]
  result: ExtrahierteDaten
}
export type VatRate = 19 | 7 | 0

export interface Company {
  id: string
  user_id: string
  name: string
  address: string
  phone: string | null
  contact_email: string | null
  website: string | null
  tax_number: string | null
  iban: string | null
  logo_url: string | null
  signature_url: string | null
  vat_rate: VatRate
  payment_days: number
  language: string
  accounting_software: AccountingSoftware
  abrechnungs_modus: 'inapp' | 'extern'
  angebot_struktur: 'raeume' | 'arbeitsablauf' | 'gewerk'
  /** Widerrufsbelehrung ans Angebot anhängen (nur bei Privatkunden) */
  widerruf_aktiv: boolean
  /** Eigener Belehrungstext; null = amtliches Muster */
  widerruf_text: string | null
  gewerke: string[]
  created_at: string
  lexoffice_api_key: string | null
  lexware_api_key: string | null
  sevdesk_api_key: string | null
  fastbill_api_key: string | null
  fastbill_email: string | null
  billomat_api_key: string | null
  billomat_subdomain: string | null
  papierkram_api_key: string | null
  easybill_api_key: string | null
  ust_id: string | null
  agb_url: string | null
  plan: string | null
  reminder_days: number | null
  regionaler_preisfaktor_prozent: number
  angebot_gueltig_tage: number
  materialpreis_hinweis_aktiv: boolean
  mindestauftragswert: number
  e_rechnung_aktiv: boolean
  onboarding_completed: boolean
  onboarding_step: number
  kleinmaterial_config: {
    aktiv?: boolean
    betrag_eur?: number
    schwelle_eur?: number
    bezeichnung?: string
  } | null
  anfahrt_config: {
    aktiv?: boolean
    betrag_eur?: number
    bezeichnung?: string
  } | null
}

export interface MengenrabattTier {
  ab: number
  rabatt_prozent: number
}

export interface PriceItem {
  id: string
  company_id: string
  category: string
  title: string
  unit: string
  unit_price: number
  description: string | null
  mengenrabatt: MengenrabattTier[] | null
  vob_norm: string | null
  din_normen: string[] | null
  ist_erschwerniszuschlag: boolean
  erschwerniszuschlag_fuer: string | null
  zuschlag_typ: 'prozent' | 'festbetrag' | 'je_einheit' | null
  nutzungshaeufigkeit: number
}

export interface Customer {
  id: string
  company_id: string
  name: string
  address: string | null
  email: string | null
  phone: string | null
  ist_unternehmen: boolean
  ustid: string | null
  leitweg_id: string | null
}

export interface Quote {
  id: string
  company_id: string
  customer_id: string | null
  status: QuoteStatus
  created_at: string
  valid_until: string | null
  total_net: number
  total_vat: number
  total_gross: number
  notes: string | null
  signed_at: string | null
  signed_by: string | null
  angebotsnummer: string | null
  briefpapier_id: string | null
  // ── Pro-Angebot-Optionen (Zahnrad) — NULL = aus Betriebs-Einstellungen erben
  angebot_struktur?: 'raeume' | 'arbeitsablauf' | 'gewerk' | null
  kopftext?: string | null
  fusstext?: string | null
  zahlungsziel_tage?: number | null
  dokument_typ?: 'angebot' | 'kostenvoranschlag' | null
  skonto_prozent?: number | null
  skonto_tage?: number | null
  widerruf_beilegen?: boolean | null
  preis_darstellung?: 'netto' | 'brutto' | null
  raum_details?: Record<string, unknown> | null
  revision: number
  original_id: string | null
  // CoS-012/DC-029: bewusst dauerhaft nullable, siehe src/lib/baustellen.ts
  baustelle_id?: string | null
  // CoS-002 Option 1 Schritt 3, Mehrfach-Aufnahmen-Fall — siehe
  // KombinierteExtraktionCache-Kommentar oben.
  kombinierte_extraktion_cache?: KombinierteExtraktionCache | null
  customer?: Customer
  items?: QuoteItem[]
}

// CoS-012/DC-029: "Baustelle"/Projekt-Zuordnung — siehe src/lib/baustellen.ts
export interface Baustelle {
  id: string
  company_id: string
  customer_id: string
  name: string
  adresse: string | null
  ist_erstbaustelle: boolean
  created_at: string
}

export interface Nummernkreis {
  id: string
  betrieb_id: string
  typ: 'angebot' | 'rechnung'
  prefix: string
  jahr_aktiv: number | null
  trennzeichen: string
  naechste_nummer: number
  min_stellen: number
  letztes_update: string
}

export interface VergebeneNummer {
  id: string
  betrieb_id: string
  typ: 'angebot' | 'rechnung'
  nummer: string
  sequenz_nummer: number
  angebot_id: string | null
  vergeben_am: string
  storniert: boolean
}

export interface Briefpapier {
  id: string
  betrieb_id: string
  name: string
  ist_standard: boolean
  firmenname: string | null
  zusatz: string | null
  strasse: string | null
  plz: string | null
  ort: string | null
  telefon: string | null
  email: string | null
  website: string | null
  logo_url: string | null
  logo_position: 'links' | 'mitte' | 'rechts'
  logo_groesse: 'klein' | 'mittel' | 'gross'
  akzentfarbe: string
  fusszeile_links: string | null
  fusszeile_mitte: string | null
  fusszeile_rechts: string | null
  schrift: 'inter' | 'roboto' | 'opensans'
  erstellt_am: string
  aktualisiert_am: string
}

export interface QuoteItem {
  id: string
  quote_id: string
  position: number
  title: string
  description: string | null
  quantity: number
  unit: string
  unit_price: number
  total_price: number
  price_item_id?: string | null
  berechnungsweg?: string | null
  annahmen?: string[]
  /** DC-027/CoS-017: true = vom Tool ergaenzt (nicht gesagt) -> "Vorschlag"-Badge. */
  automatisch_ergaenzt?: boolean
  vob_norm: string | null
  din_normen: string[] | null
}
