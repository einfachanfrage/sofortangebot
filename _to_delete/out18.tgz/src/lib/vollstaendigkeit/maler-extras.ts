import type { BerechnetePosition } from '../mengen/types'
import { hat, add, anzahlAus, filtereArray } from './helpers'
import type { AuftragsVerstaendnis } from '../auftrags-verstaendnis'
import { extrahiereRaumhoehe } from '../extraktion-masse'
import { ZUSCHLAG_EINHEIT } from '../zuschlag-basis'

export function pruefeErschwerniszuschlagHoehe(
  ergaenzt: BerechnetePosition[],
  lower: string,
  // PM-024-Nachtest (2026-08-30): Die Prüfung las AUSSCHLIESSLICH den Rohtext —
  // obwohl die Extraktion die Höhe längst sauber als Zahl geliefert hatte
  // (3,2 m stand korrekt in den Raummaßen). Fehlte dem Parser die Sprechweise
  // („Höhe 3,20 m" kannte er nicht), fiel der Zuschlag lautlos aus. Jetzt gilt
  // dieselbe Rangordnung wie überall: erkannte Struktur vor Rohtext-Regex.
  raeume: Array<{ name?: string; hoehe?: number | null }> = [],
): void {
  const SCHWELLE = 3.0
  if (hat(ergaenzt, 'erschwerniszuschlag höhe', 'höhe zuschlag', 'gerüst')) return

  // Sandys Entscheidung (2026-08-30): Der Zuschlag gehört ZUM RAUM, nicht in
  // eine Sammelkarte „Allgemein" — er entsteht ja durch genau diesen einen
  // hohen Raum. Bei mehreren hohen Räumen entsteht er entsprechend mehrfach:
  // der Mehraufwand (Leiter, Gerüst, Aufbau) fällt in jedem Raum erneut an.
  const hoheRaeume = raeume.filter(r => typeof r.hoehe === 'number' && (r.hoehe ?? 0) > SCHWELLE)
  if (hoheRaeume.length > 0) {
    for (const raum of hoheRaeume) {
      const suffix = raum.name ? ` — ${raum.name}` : ''
      if (hat(ergaenzt, `erschwerniszuschlag raumhöhe > 3m${suffix}`.toLowerCase())) continue
      ergaenzt.push({
        beschreibung: `Erschwerniszuschlag Raumhöhe > 3m${suffix}`,
        menge: 1, einheit: ZUSCHLAG_EINHEIT, konfidenz: 'high',
        berechnungsweg: `Raumhöhe ${raum.hoehe}m > ${SCHWELLE}m`, annahmen: [],
      })
    }
    return
  }

  // Kein strukturiertes Maß über der Schwelle: wie bisher der Rohtext als
  // Rückfallebene — dann aber ohne Raumbezug, weil keiner bekannt ist.
  const ausText = extrahiereRaumhoehe(lower) ?? 0
  const hatHohesRaum = ausText > SCHWELLE
    || lower.includes('hohe decke') || lower.includes('hohen decken')
  if (hatHohesRaum) {
    ergaenzt.push({ beschreibung: 'Erschwerniszuschlag Raumhöhe > 3m', menge: 1, einheit: ZUSCHLAG_EINHEIT, konfidenz: 'high', berechnungsweg: `Raumhöhe ${ausText > 0 ? ausText + 'm' : 'erkannt'} > ${SCHWELLE}m`, annahmen: [] })
  }
}

// PM-019 (2026-08-21): echter Live-Fund. Das Fachwissen kennt drei
// gleichwertige Erschwernis-Trigger — Raumhöhe > 3m, Altbau, und
// "schwieriger Untergrund" — aber nur die ersten beiden hatten hier
// überhaupt eine Erkennung. GPTs eigene Extraktion tagt "schwieriger
// Untergrund" bereits sauber als eigenes `erschwernisse`-Feld
// (`["unebener und bröckeliger Putz"]`, bestätigt an echten
// Produktionsrohdaten) — nur unsere Vollständigkeitsprüfung hat nie danach
// gesehen. Bewusst wie Höhe/Altbau/Denkmalschutz direkt gegen den
// Rohtranskript-Text geprüft (nicht gegen das `erschwernisse`-Feld), damit
// dieselbe robuste, deterministische Erkennung greift, egal ob GPTs
// Struktur-Extraktion es diesmal sauber tagt oder nicht.
// ── PM-011, Befund (Prüfmeister, 05.09.2026) ──────────────────────────────
//
// „Erschwerniszuschlag schwieriger Untergrund 10 % = 98,10 €" stand neben
// „Spachtelarbeiten Q2 · 36,00 m² · 324,00 €". Das ist dieselbe Erschwernis
// zweimal kassiert.
//
// Seine Regel, entschieden am 02.09.: *Steht im selben Raum eine
// Vollflächenspachtelung (Q2 bis Q4), wird „Erschwerniszuschlag schwieriger
// Untergrund" nicht gesetzt.* Die Unebenheit IST die Spachtelung — sie steht
// bereits als eigene, bepreiste Position im Angebot. „Genau das ist der
// Punkt, an dem ein Kunde zu Recht laut wird."
//
// Der Altbau-Zuschlag bleibt ausdrücklich davon unberührt: „der zahlt nicht
// die Wand, sondern die Baustelle drumherum."
//
// ── Zwei Fallen, in die der erste Entwurf gelaufen wäre ───────────────────
//
// 1. REIHENFOLGE. Die Spachtel-Positionen entstehen zum größten Teil erst in
//    `pruefeSpachteln()` und `pruefeSpachtelarbeiten()`. Der Zuschlag wurde
//    aber VOR beiden geprüft — eine Abfrage auf eine Liste, in der die
//    Spachtelung noch gar nicht steht, hätte still nie ausgelöst. Deshalb ist
//    der Aufruf in `maler.ts` ans Ende gewandert, hinter beide. Genau die
//    Sorte stiller Prüfung, die diese Woche schon viermal Geld gekostet hat.
//
// 2. PUNKTUELLES SPACHTELN ZÄHLT NICHT. „Dübellöcher spachteln" und
//    „Risse / Löcher spachteln (kleine Schadstellen)" sind Kleinreparaturen,
//    keine Vollflächenspachtelung — sie beantworten einen bröckeligen
//    Untergrund NICHT und dürfen den Zuschlag nicht schlucken. Das Muster
//    trifft deshalb nur die flächigen Positionen und schreibt „ä" nie als
//    einzelne Schreibweise (\büberall\b lässt grüßen).
const VOLLFLAECHENSPACHTELUNG = /spachtelarbeiten|(?:w(?:ä|ae|a)nde|decken?)\s+spachteln|vollfl[äa]chig.{0,20}spachtel|spachtel\w*.{0,20}vollfl[äa]chig/i

export function pruefeErschwerniszuschlagUntergrund(ergaenzt: BerechnetePosition[], lower: string): void {
  const hatSchwierigenUntergrund =
    /schwierig\w*\s+untergrund|untergrund\w*\s+(?:ist\s+)?schwierig|br[öo]ckel|uneben\w*.{0,40}(?:putz|untergrund|wand|wände|waende)|(?:putz|untergrund|wand|wände|waende).{0,40}uneben\w*/i.test(lower)
  // Die Spachtelung ist die bezahlte Antwort auf den unebenen Untergrund.
  const hatSpachtelung = ergaenzt.some(p => VOLLFLAECHENSPACHTELUNG.test(p.beschreibung))
  if (hatSpachtelung) return
  if (hatSchwierigenUntergrund && !hat(ergaenzt, 'erschwerniszuschlag untergrund', 'untergrund zuschlag')) {
    ergaenzt.push({
      beschreibung: 'Erschwerniszuschlag schwieriger Untergrund',
      menge: 1,
      einheit: ZUSCHLAG_EINHEIT,
      konfidenz: 'high',
      berechnungsweg: 'Schwieriger/unebener Untergrund im Transkript erkannt',
      annahmen: [],
    })
  }
}

export function pruefeGraffiti(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string): void {
  const hatGraffiti = lower.includes('graffiti') || lower.includes('schmiererei') || lower.includes('vandalism')
  if (!hatGraffiti || hat(ergaenzt, 'graffiti entfern')) return

  const m2Match = lower.match(/(\d+(?:[.,]\d+)?)\s*(?:m²|qm|quadratmeter)/i)
  const gm2 = m2Match ? parseFloat(m2Match[1].replace(',', '.')) : null
  if (gm2 !== null && gm2 > 0) {
    ergaenzt.push({ beschreibung: 'Graffiti entfernen', menge: gm2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `${gm2} m² aus Transkript`, annahmen: [] })
    ergaenzt.push({ beschreibung: 'Grundierung Fassade nach Graffiti', menge: gm2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `${gm2} m²`, annahmen: [] })
    ergaenzt.push({ beschreibung: 'Fassadenfarbe 2× Anstrich', menge: gm2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `${gm2} m²`, annahmen: [] })
  } else {
    add(ergaenzt, fehlende, 'Graffiti entfernen')
    add(ergaenzt, fehlende, 'Grundierung Fassade nach Graffiti')
    add(ergaenzt, fehlende, 'Fassadenfarbe 2× Anstrich')
  }
}

export function pruefeAltbau(ergaenzt: BerechnetePosition[], lower: string): void {
  const hatAltbau = lower.includes('altbau') || lower.includes('altgebäude') || lower.includes('altbestand')
  if (hatAltbau && !hat(ergaenzt, 'erschwerniszuschlag altbau', 'altbau pauschale')) {
    ergaenzt.push({ beschreibung: 'Erschwerniszuschlag Altbau', menge: 1, einheit: ZUSCHLAG_EINHEIT, konfidenz: 'high', berechnungsweg: 'Altbau im Transkript erkannt', annahmen: [] })
  }
}

export function pruefeDenkmalschutz(ergaenzt: BerechnetePosition[], lower: string): void {
  const hatDenkmal = lower.includes('denkmal') || lower.includes('denkmalschutz') || lower.includes('denkmalgeschütz')
  if (hatDenkmal && !hat(ergaenzt, 'erschwerniszuschlag denkmal', 'denkmal pauschale')) {
    ergaenzt.push({ beschreibung: 'Erschwerniszuschlag Denkmalschutz', menge: 1, einheit: ZUSCHLAG_EINHEIT, konfidenz: 'high', berechnungsweg: 'Denkmalschutz im Transkript erkannt', annahmen: [] })
  }
}

/**
 * Die genannte Qualitätsstufe — mit Wortgrenzen, damit „Q3," genauso zählt
 * wie „Q3." und „Q3 ". Ohne Nennung gilt Q2 als Annahme (siehe unten).
 */
function qStufe(lower: string): 'Q2' | 'Q3' | 'Q4' {
  if (/\bq4\b/i.test(lower)) return 'Q4'
  if (/\bq3\b/i.test(lower)) return 'Q3'
  return 'Q2'
}

export function pruefeSpachteln(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string, v: AuftragsVerstaendnis): void {
  const hatStreichen = v.hatArbeit('streichen')
  const hatSpachteln = lower.includes('spachtel') || lower.includes('q2') || lower.includes('q3') || lower.includes('q4')
  const istNurSpachteln = hatSpachteln && !hatStreichen
    // PM-018 (Prüfmeister, 04.09.2026): Hier stand `includes(' q3 ')` — mit
    // Leerzeichen auf BEIDEN Seiten. Im Diktat steht „Qualitätsstufe Q3,
    // weil später Streiflicht draufscheint": nach dem Q3 kommt ein Komma,
    // der Vergleich lief ins Leere. Zwei Zeilen weiter unten wurde es im
    // selben File längst richtig mit Wortgrenzen gemacht. Jetzt überall
    // dieselbe Prüfung — dann ist es egal, ob Komma, Punkt oder Satzende
    // folgt. Dieselbe Familie wie \büberall\b und \bdämm: eine Prüfung, die
    // an der Zeichensetzung scheitert und dabei still bleibt.
    && (lower.includes('spachtel') || /\bq[2-4]\b/i.test(lower))
  if (!istNurSpachteln || hat(ergaenzt, 'spachteln', 'spachelarbeit')) return

  const qLevel = qStufe(lower)
  const wandPos = ergaenzt.find(p => p.beschreibung.toLowerCase().includes('wand') && p.einheit === 'm²')
  const spachtelM2 = wandPos?.menge ?? null
  if (spachtelM2 !== null && spachtelM2 > 0) {
    ergaenzt.push({ beschreibung: `Wände spachteln ${qLevel}`, menge: spachtelM2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `${spachtelM2} m² Wandfläche`, annahmen: [] })
    ergaenzt.push({ beschreibung: `Wände schleifen nach ${qLevel}`, menge: spachtelM2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `${spachtelM2} m²`, annahmen: [] })
  } else {
    add(ergaenzt, fehlende, `Wände spachteln ${qLevel}`)
    add(ergaenzt, fehlende, `Wände schleifen nach ${qLevel}`)
  }
}

export function pruefeSpachtelarbeiten(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string, v: AuftragsVerstaendnis): void {
  const hatStreichen = v.hatArbeit('streichen')
  const hatSpachteln2 = lower.includes('spachtel') || lower.includes('q2') || lower.includes('q3')
  const hatSchleifenArb = /\b(?:schleif\w*|geschliff\w*)\b/i.test(lower) && !lower.includes('abschleif')
  if (!hatSpachteln2 && !hatSchleifenArb) return

  // Einzelne Dübellöcher und Schadstellen sind Kleinreparaturen, keine
  // vollflächige Q2-Spachtelung. Sie müssen als eigene Stückpositionen erhalten
  // bleiben, statt unbemerkt die komplette Wandfläche zu verteuern.
  //
  // PM-011, Nachtest (2026-08-17/19/20): "...nicht nur ne kleine Ausbesserung,
  // wirklich die ganze Fläche" hat trotzdem die Kleinreparatur-Stückposition
  // "Risse / Löcher spachteln" erzeugt — der Nutzer hat die Kleinreparatur-
  // Einordnung ausdrücklich VERNEINT, aber der reine Substring-Check unten
  // sucht nur nach der Wortfolge "kleine[r] Ausbesserung/Loch/Löcher" im
  // Text, ohne auf ein direkt davorstehendes "kein[e]"/"nicht nur/bloß/
  // allein" zu achten — exakt dieselbe Fehlerklasse wie "kein Fenster"/
  // "keine Tür" (arbeiten-normalisierer.ts) oder "keine Dehnungsfuge"
  // (PM-013, aufnahme-hinweise.ts). Gleiche Lösung: Verneinung direkt vor
  // der Wortfolge ausschließen, für Dübellöcher und Schadstellen
  // gleichermaßen (dieselbe Fehlerklasse an derselben Stelle).
  const kleinreparaturVerneint = /(?:kein[e]?\s|nicht\s+(?:nur|bloß|allein)\s+)[^.!?]{0,20}?(?:d[üu]bell[öo]ch\w*|bohrl[öo]ch\w*|nagell[öo]ch\w*|schadstell\w*|fehlstell\w*|\bloch\b|l[öo]cher|ausbesser\w*)/i
  const hatDuebelloecher = /dübellöch|duebelloech|bohrlöch|nagellöch/i.test(lower) && !kleinreparaturVerneint.test(lower)
  const hatSchadstellen = /schadstell|fehlstell|kleine[nr]?\s+(?:loch|löcher|ausbesser)/i.test(lower) && !kleinreparaturVerneint.test(lower)
  if (hatDuebelloecher || hatSchadstellen) {
    if (hatDuebelloecher && !hat(ergaenzt, 'dübellöcher', 'duebelloecher')) {
      const anzahl = anzahlAus(lower, 'dübellöch', 1)
      ergaenzt.push({
        beschreibung: 'Dübellöcher spachteln',
        menge: anzahl,
        einheit: 'Stück',
        konfidenz: anzahl > 1 ? 'high' : 'medium',
        berechnungsweg: anzahl > 1 ? `${anzahl} Stück aus Aufnahme` : 'Mindestens eine Kleinreparatur erkannt',
        annahmen: anzahl > 1 ? [] : ['Anzahl 1 angenommen — bitte prüfen'],
      })
    }
    if (hatSchadstellen && !hat(ergaenzt, 'risse / löcher spachteln', 'kleine schadstellen')) {
      const anzahl = anzahlAus(lower, 'schadstell', 1)
      ergaenzt.push({
        beschreibung: 'Risse / Löcher spachteln (kleine Schadstellen)',
        menge: anzahl,
        einheit: 'Stück',
        konfidenz: anzahl > 1 ? 'high' : 'medium',
        berechnungsweg: anzahl > 1 ? `${anzahl} Stück aus Aufnahme` : 'Mindestens eine Schadstelle erkannt',
        annahmen: anzahl > 1 ? [] : ['Anzahl 1 angenommen — bitte prüfen'],
      })
    }
    // Nur eine zusätzlich ausdrücklich genannte vollflächige Qualitätsstufe
    // darf daneben noch Q2/Q3/Q4 erzeugen.
    if (!/\bq[1-4]\b|vollflächig|ganze\s+wandfl/i.test(lower)) return
  }

  // PM-018: die Position hieß bisher IMMER "Spachtelarbeiten Q2", selbst
  // wenn der Kunde ausdrücklich Q3/Q4 verlangt hat — die Prüfung, OB eine
  // Qualitätsstufe genannt wurde, existierte schon (für die "angenommen"-
  // Annahme unten), nur die tatsächlich genannte Stufe wurde nie in die
  // Beschreibung übernommen. Gleiche Lehre wie bei "Q2" in pruefeSpachteln().
  const qLevel = qStufe(lower)
  const spachtelnSchonVorhanden = hat(ergaenzt, 'spachtelarbeiten')
  const schleifenSchonVorhanden = ergaenzt.some(p => /\bschleifen\b/i.test(p.beschreibung))

  const deckeExplizitSpachteln = /deck\w*(?:\s+\w+){0,4}\s+spachtel|spachtel\w*(?:\s+\w+){0,4}\s+deck/i.test(lower)
  const basisPositionen = ergaenzt.filter(p => {
    const d = p.beschreibung.toLowerCase()
    return (d.includes('wandfläch') || (deckeExplizitSpachteln && d.includes('deckenfläch'))) && p.einheit === 'm²'
  })
  if (basisPositionen.length > 0) {
    for (const basisPos of basisPositionen) {
      const raumMatch = basisPos.beschreibung.match(/ — (.+)$/)
      const raumSuffix = raumMatch ? ` — ${raumMatch[1]}` : ''
      // PM-018, Darstellungsfund 1: Wand- und Deckenposition hießen
      // IDENTISCH „Spachtelarbeiten Q2", einmal mit 39 und einmal mit 14 m².
      // Auf dem Kundenangebot standen zwei gleiche Zeilen mit verschiedenen
      // Mengen, und niemand konnte sagen, welche die Decke ist. Die
      // Grundierung macht es zwei Zeilen weiter richtig vor.
      const istDecke = basisPos.beschreibung.toLowerCase().includes('deckenfläch')
      const flaechenTeil = istDecke ? ' Decke' : ''
      if (hatSpachteln2 && !spachtelnSchonVorhanden) ergaenzt.push({
        beschreibung: `Spachtelarbeiten ${qLevel}${flaechenTeil}${raumSuffix}`,
        // PM-018, Darstellungsfund 3: Beide Zeilen trugen das Etikett
        // „Vorschlag", obwohl „Wände UND Decke komplett spachteln" eine
        // Ansage ist. Ein Vorschlag ist etwas, das WIR mitdenken; wenn das
        // Etikett auch an Gesagtem klebt, verliert es überall seine
        // Bedeutung. Es bleibt nur dort, wo wir die Stufe geraten haben.
        ...(lower.includes('spachtel') ? { automatisch_ergaenzt: false } : {}),
        menge: basisPos.menge,
        einheit: 'm²',
        konfidenz: 'high',
        berechnungsweg: `Gleiche Fläche wie ${basisPos.beschreibung.split(' — ')[0]}`,
        annahmen: [
          ...basisPos.annahmen,
          ...(/\bq[1-4]\b/i.test(lower) ? [] : ['Qualitätsstufe Q2 angenommen — bitte prüfen; Q3/Q4 werden abweichend kalkuliert']),
        ],
      })
      if (hatSchleifenArb && !schleifenSchonVorhanden) ergaenzt.push({ beschreibung: `Schleifen${raumSuffix}`, menge: basisPos.menge, einheit: 'm²', konfidenz: 'high', berechnungsweg: `Gleiche Fläche wie ${basisPos.beschreibung.split(' — ')[0]}`, annahmen: [...basisPos.annahmen] })
    }
  } else {
    if (hatSpachteln2 && !spachtelnSchonVorhanden) add(ergaenzt, fehlende, `Spachtelarbeiten ${qLevel}`)
    if (hatSchleifenArb && !schleifenSchonVorhanden) add(ergaenzt, fehlende, 'Schleifen')
  }
  void hatStreichen // unused but preserved for clarity
}

export function pruefeEstrich(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string): void {
  // \bestrich statt includes('estrich') — sonst matcht "gESTRICHen" (Partizip von streichen)!
  const hatEstrich = /\bestrich/i.test(lower) || lower.includes('epoxid') || lower.includes('versiegeln')
  if (!hatEstrich || hat(ergaenzt, 'estrich schleifen', 'epoxid')) return

  const bodenPosEstrich = ergaenzt.find(p => p.beschreibung.toLowerCase().includes('boden'))
  const em2 = bodenPosEstrich?.menge ?? null
  if (em2 !== null && em2 > 0) {
    filtereArray(ergaenzt, p => !p.beschreibung.toLowerCase().includes('boden schütz') && !p.beschreibung.toLowerCase().includes('boden — '))
    ergaenzt.push({ beschreibung: 'Estrich schleifen / Untergrundvorbereitung', menge: em2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `Bodenfläche ${em2} m²`, annahmen: [] })
    ergaenzt.push({ beschreibung: 'Epoxid / Versiegelung — Schicht 1', menge: em2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `Bodenfläche ${em2} m²`, annahmen: [] })
    ergaenzt.push({ beschreibung: 'Epoxid / Versiegelung — Schicht 2', menge: em2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `Bodenfläche ${em2} m²`, annahmen: [] })
  } else {
    add(ergaenzt, fehlende, 'Estrich schleifen / Untergrundvorbereitung')
    add(ergaenzt, fehlende, 'Epoxid / Versiegelung — Schicht 1')
    add(ergaenzt, fehlende, 'Epoxid / Versiegelung — Schicht 2')
  }
}

export function pruefeGaragenboden(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string): void {
  const hatGaragenboden = (lower.includes('garagenboden') || (lower.includes('garage') && lower.includes('boden')))
    && (lower.includes('beton') || lower.includes('betonfarbe') || lower.includes('grau'))
  if (!hatGaragenboden || hat(ergaenzt, 'garagenboden', 'garagenbod')) return

  const bodenPosGar = ergaenzt.find(p => p.beschreibung.toLowerCase().includes('boden'))
  const gm2 = bodenPosGar?.menge ?? null
  if (gm2 !== null && gm2 > 0) {
    ergaenzt.unshift({ beschreibung: 'Garagenboden Betonfarbe', menge: gm2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `Bodenfläche ${gm2} m²`, annahmen: [] })
  } else {
    add(ergaenzt, fehlende, 'Garagenboden Betonfarbe')
  }
}

export function pruefeGeruest(ergaenzt: BerechnetePosition[], lower: string): void {
  const hatGeruest = lower.includes('gerüst') || lower.includes('geruest') || lower.includes('gerüst nötig')
  if (hatGeruest && !hat(ergaenzt, 'gerüst', 'geruest')) {
    ergaenzt.push({ beschreibung: 'Gerüst stellen und abbauen', menge: 1, einheit: 'Pauschale', konfidenz: 'high', berechnungsweg: 'Gerüst im Transkript erwähnt', annahmen: [] })
  }
}

export function pruefeBewohnt(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string): void {
  const hatBewohnt = lower.includes('bewohnt') || lower.includes('möbel') || lower.includes('einrichtung') || lower.includes('bewohnte')
  if (!hatBewohnt) return

  if (!hat(ergaenzt, 'möbel schütz', 'möbel abdeck')) {
    const bodenPos = ergaenzt.find(p => p.beschreibung.toLowerCase().includes('boden'))
    const bodenmenge = bodenPos?.menge ?? null
    if (bodenmenge !== null) {
      ergaenzt.push({ beschreibung: 'Möbel schützen / Abdecken', menge: bodenmenge, einheit: 'm²', konfidenz: 'high', berechnungsweg: `Bodenfläche ${bodenmenge} m²`, annahmen: [] })
    } else {
      add(ergaenzt, fehlende, 'Möbel schützen / Abdecken')
    }
  }
  if (!hat(ergaenzt, 'erschwerniszuschlag bewohnt')) {
    ergaenzt.push({ beschreibung: 'Erschwerniszuschlag bewohnt', menge: 1, einheit: ZUSCHLAG_EINHEIT, konfidenz: 'high', berechnungsweg: 'Bewohnter Zustand im Transkript erkannt', annahmen: [] })
  }
}

// PM-021 (2026-08-21): loses `includes('terrasse')` fing auch "Terrassentür"
// als Türbezeichnung — Sandys Live-Fall nannte nur eine Terrassentür (Öffnung
// im Wohnküche-Raum selbst), nie einen tatsächlichen Balkon/eine Terrasse als
// eigenen Ort. Trotzdem wurde ein kompletter Phantom-Workflow ausgelöst:
// "Balkonboden streichen" mit 30 m² — exakt der Fläche des Wohnküche-Raums
// selbst (5×6), nicht irgendeiner plausiblen Balkongröße. Dieselbe
// Ein-Wort-Über-Erkennungs-Fehlerklasse wie PM-010 ("kommen raus" → Phantom-
// Bodenaustausch) und PM-017 ("tapezieren" → vier Phantom-Positionen). Fix:
// "balkon"/"terrasse"/"loggia" müssen als eigenständiger Ort erkannt werden —
// ein Treffer direkt gefolgt von "tür" (ggf. mit "n"-Fuge wie bei
// "Terrassentür" oder direkt wie bei "Balkontür") zählt nur als Türname,
// nicht als Ortsangabe. Echte Wortzusammensetzungen wie "Balkonboden" oder
// "Terrassenbrüstung" bleiben davon unberührt (kein "tür" direkt danach).
const BALKON_ORT = /balkon(?!s?t[üu]r)\w*|loggia(?!t[üu]r)\w*|terrasse(?!nt[üu]r)\w*/i

export function pruefeBalkon(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string): void {
  const hatBalkon = BALKON_ORT.test(lower)
  if (!hatBalkon || hat(ergaenzt, 'balkonboden', 'brüstung', 'terrasse')) return

  const hatBeton = lower.includes('beton') || lower.includes('betonfarbe')
  const hatBruestung = lower.includes('brüstung') || lower.includes('bruestung') || lower.includes('geländer')
  const bodenPos = ergaenzt.find(p => p.beschreibung.toLowerCase().includes('boden'))
  const bodenM2 = bodenPos?.menge ?? null
  const beschrBoden = hatBeton ? 'Balkonboden Betonfarbe' : 'Balkonboden streichen'

  if (bodenM2 !== null) {
    ergaenzt.push({ beschreibung: beschrBoden, menge: bodenM2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `Bodenfläche ${bodenM2} m²`, annahmen: [] })
  } else {
    add(ergaenzt, fehlende, beschrBoden)
  }
  if (hatBruestung) {
    const lfdmBrMatch = lower.match(/brüst(?:ung)?[^.!?]*?(\d+(?:[.,]\d+)?)\s*(?:lfm|lfdm|laufende?r?\s*meter|meter)/i)
    const lfdmBr = lfdmBrMatch ? parseFloat(lfdmBrMatch[1].replace(',', '.')) : null
    const hBrMatch = lower.match(/brüst(?:ung)?[^.!?]*?(\d+(?:[.,]\d+)?)\s*m?\s*hoch/i)
      ?? lower.match(/(\d+(?:[.,]\d+)?)\s*m?\s*hoch[^.!?]*?brüst/i)
    const hBr = hBrMatch ? parseFloat(hBrMatch[1].replace(',', '.')) : 1.0
    if (lfdmBr !== null && lfdmBr > 0) {
      const brM2 = Math.round(lfdmBr * hBr * 100) / 100
      ergaenzt.push({ beschreibung: 'Brüstung innen streichen', menge: brM2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `${lfdmBr} lfm × ${hBr} m = ${brM2} m²`, annahmen: [] })
    } else {
      add(ergaenzt, fehlende, 'Brüstung innen streichen')
    }
  }
  if (hatBeton && !hat(ergaenzt, 'untergrundvorbereitung beton', 'betonvorbereitung')) {
    ergaenzt.push({ beschreibung: 'Untergrundvorbereitung Beton', menge: 1, einheit: 'Pauschale', konfidenz: 'high', berechnungsweg: 'Betonuntergrund im Transkript erkannt', annahmen: [] })
  }
}

export function pruefeHolzOelen(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string): void {
  const hatHolzOelen = (lower.includes('holzdecke') || (lower.includes('holz') && (lower.includes('decke') || lower.includes('dielen') || lower.includes('holzbalken'))))
    && (lower.includes('öl') || lower.includes('oel') || lower.includes('ölen'))
  if (!hatHolzOelen || hat(ergaenzt, 'holzdecke abschleifen', 'holzdecke ölen')) return

  const m2Match = lower.match(/(\d+(?:[.,]\d+)?)\s*(?:m²|qm|quadratmeter)/i)
  const hm2 = m2Match ? parseFloat(m2Match[1].replace(',', '.')) : null
  if (hm2 !== null && hm2 > 0) {
    ergaenzt.push({ beschreibung: 'Holzdecke abschleifen', menge: hm2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `${hm2} m² aus Transkript`, annahmen: [] })
    ergaenzt.push({ beschreibung: 'Holzdecke ölen — 2× Anstrich', menge: hm2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `${hm2} m²`, annahmen: [] })
    if (!hat(ergaenzt, 'boden schütz', 'abdeck')) {
      ergaenzt.push({ beschreibung: 'Boden schützen / Abdecken', menge: hm2, einheit: 'm²', konfidenz: 'high', berechnungsweg: `Schutz unter Deckenfläche ${hm2} m²`, annahmen: [] })
    }
  } else {
    add(ergaenzt, fehlende, 'Holzdecke abschleifen')
    add(ergaenzt, fehlende, 'Holzdecke ölen — 2× Anstrich')
    add(ergaenzt, fehlende, 'Boden schützen / Abdecken')
  }
}

export function pruefeBrandschutzfarbe(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string): void {
  const hatBrandschutzfarbe = lower.includes('brandschutzfarbe') || lower.includes('brandschutz f') || lower.includes('brandschutz stahl')
  if (!hatBrandschutzfarbe || hat(ergaenzt, 'brandschutzfarbe', 'rostschutz')) return

  const lfdmMatch = lower.match(/(\d+)\s*(?:stück|träger)[^.!?]*?(\d+)\s*m/i)
  const anzTraeger = lfdmMatch ? parseInt(lfdmMatch[1]) : anzahlAus(lower, 'träger', 1)
  const laengeTraeger = lfdmMatch ? parseFloat(lfdmMatch[2]) : anzahlAus(lower, 'meter', anzahlAus(lower, 'm lang', 0))
  const lfdmTraeger = anzTraeger * (laengeTraeger > 0 ? laengeTraeger : 1)
  if (lfdmTraeger > 1) {
    ergaenzt.push({ beschreibung: 'Rostschutzgrund Träger', menge: lfdmTraeger, einheit: 'lfdm', konfidenz: 'medium', berechnungsweg: `${anzTraeger} Träger × ${laengeTraeger} m`, annahmen: ['Alle Seiten mit Standardbreite'] })
    ergaenzt.push({ beschreibung: 'Brandschutzfarbe F30/F60', menge: lfdmTraeger, einheit: 'lfdm', konfidenz: 'high', berechnungsweg: `${lfdmTraeger} lfdm`, annahmen: [] })
  } else {
    add(ergaenzt, fehlende, 'Rostschutzgrund Träger')
    add(ergaenzt, fehlende, 'Brandschutzfarbe F30/F60')
  }
}

export function pruefeStuckleisten(ergaenzt: BerechnetePosition[], fehlende: string[], lower: string, v: AuftragsVerstaendnis): void {
  const hatStuckleisten = lower.includes('stuckleiste') || lower.includes('stuckleis')
    || lower.includes('stuckprofil') || lower.includes('stuck montier')
  if (!hatStuckleisten || hat(ergaenzt, 'stuckleisten montier', 'stuckelemente montier')) return

  const flaecheMatch = lower.match(/(\d+(?:[.,]\d+)?)\s*(?:m²|qm|quadratmeter)/i)
  const fm2 = flaecheMatch ? parseFloat(flaecheMatch[1].replace(',', '.')) : null
  const umfangGeschaetzt = fm2 !== null ? Math.round(4 * Math.sqrt(fm2)) : null
  const umfangAusEngine = ergaenzt.find(p => p.einheit === 'lfdm' && p.beschreibung.toLowerCase().includes('sockel'))?.menge ?? null
  const stuckM = umfangAusEngine ?? umfangGeschaetzt
  if (stuckM !== null && stuckM > 0) {
    ergaenzt.push({ beschreibung: 'Stuckleisten montieren', menge: stuckM, einheit: 'lfdm', konfidenz: 'high', berechnungsweg: fm2 ? `Umfang ≈ 4 × √${fm2} m² = ${stuckM} lfdm (voller Umfang, kein Türabzug)` : `${stuckM} lfdm`, annahmen: fm2 ? ['Quadratischer Raum angenommen'] : [] })
    if (v.hatArbeit('streichen')) {
      ergaenzt.push({ beschreibung: 'Stuckleisten streichen / weißen', menge: stuckM, einheit: 'lfdm', konfidenz: 'high', berechnungsweg: `${stuckM} lfdm`, annahmen: [] })
    }
  } else {
    add(ergaenzt, fehlende, 'Stuckleisten montieren')
    if (v.hatArbeit('streichen')) add(ergaenzt, fehlende, 'Stuckleisten streichen / weißen')
  }
}

export function pruefeStuck(ergaenzt: BerechnetePosition[], lower: string): void {
  const hatStuck = lower.includes('stuck') || lower.includes('stuckdecke') || lower.includes('stuckelement') || lower.includes('stuckrosette')
  if (!hatStuck || hat(ergaenzt, 'stuck abkl', 'stuckdecke abkl', 'stuckrosette', 'stuck restau')) return

  const istRosette = lower.includes('stuckrosette') || lower.includes('rosette')
  const istRestaurieren = lower.includes('stuck restau') || lower.includes('stuckrestau') ||
    (lower.includes('stuck') && (lower.includes('restau') || lower.includes('sanieren') || lower.includes('instandsetz')))
  if (istRosette) {
    const anzRosetten = anzahlAus(lower, 'rosette', anzahlAus(lower, 'stuckrosette', 1))
    ergaenzt.push({ beschreibung: 'Stuckrosette abkleben', menge: anzRosetten, einheit: 'Stück', konfidenz: 'high', berechnungsweg: `${anzRosetten} Stuckrosette(n) aus Transkript`, annahmen: [] })
  } else if (istRestaurieren) {
    ergaenzt.push({ beschreibung: 'Stuck restaurieren', menge: 1, einheit: 'Pauschale', konfidenz: 'high', berechnungsweg: 'Stuckrestaurierung im Transkript erkannt', annahmen: [] })
  } else {
    ergaenzt.push({ beschreibung: 'Stuckdecke / Stuckelemente abkleben', menge: 1, einheit: 'Pauschale', konfidenz: 'high', berechnungsweg: 'Stuck im Transkript erkannt', annahmen: [] })
  }
}

export function pruefeTuerrahmen(ergaenzt: BerechnetePosition[], lower: string): void {
  const hatTuerrahmen = lower.includes('türrahmen') || lower.includes('tuerrahmen') || lower.includes('türrahmen streich')
  if (!hatTuerrahmen || hat(ergaenzt, 'türrahmen')) return

  const anzRahmen = anzahlAus(lower, 'türrahmen', anzahlAus(lower, 'tuerrahmen', 3))
  ergaenzt.push({ beschreibung: 'Türrahmen schleifen', menge: anzRahmen, einheit: 'Stück', konfidenz: 'high', berechnungsweg: `${anzRahmen} Türrahmen aus Transkript`, annahmen: [] })
  ergaenzt.push({ beschreibung: 'Türrahmen streichen', menge: anzRahmen, einheit: 'Stück', konfidenz: 'high', berechnungsweg: `${anzRahmen} Türrahmen`, annahmen: [] })
}
