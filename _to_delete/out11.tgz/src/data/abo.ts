import 'server-only'

import { requireCompany } from './auth'
import { PRICING } from '@/lib/pricing'

// ── DC-045 (Product Designer, 06.09.2026) ─────────────────────────────────
//
// „Kein Zugang zur Abo-/Plan-Verwaltung nach dem Onboarding." Das
// Plan-Fenster wurde ausschließlich aus `?welcome=new` geöffnet — also
// einmalig, direkt nach frischem Onboarding. Wer den Moment verpasst hat
// oder später wechseln will, fand nichts: kein Plan-Wechsel, keine
// Rechnungshistorie, keine Zahlungsmethode.
//
// Zweiter Teil des Befundes, bewusst NICHT hier gelöst: Das beworbene
// Kontingent von 3 Angeboten pro Monat wird nirgends durchgesetzt. Ob es
// eine harte Grenze wird, eine Warnung oder gestrichen gehört, ist eine
// Geschäftsentscheidung und liegt bei Sandy. Diese Datei zählt deshalb nur
// und sperrt nichts — die Zahl sichtbar zu machen ist in jedem Fall richtig,
// eine Sperre einzubauen, die niemand beschlossen hat, wäre es nicht.

export interface AboStand {
  plan: 'starter' | 'pro'
  /** Ende der laufenden Abrechnungsperiode (nur bei Pro gesetzt). */
  laeuftBisISO: string | null
  /** Ist bei Stripe ein Kunde hinterlegt? Ohne das gibt es kein Portal. */
  hatStripeKonto: boolean
  /** In diesem Kalendermonat angelegte Angebote. */
  angeboteDiesenMonat: number
  /** Freikontingent laut Preisliste — im Starter-Plan die Bezugsgröße. */
  freikontingent: number
}

export async function getAboStand(): Promise<AboStand> {
  const { supabase, company } = await requireCompany()

  const jetzt = new Date()
  const monatsStart = new Date(jetzt.getFullYear(), jetzt.getMonth(), 1).toISOString()

  const [{ data: firma }, { count }] = await Promise.all([
    supabase.from('companies')
      .select('plan, plan_expires_at, stripe_customer_id')
      .eq('id', company.id).single(),
    // Gezählt wird, was in diesem Kalendermonat ANGELEGT wurde — nicht, was
    // versendet oder angenommen wurde. Wenn daraus einmal eine echte Grenze
    // wird, muss genau diese Definition auch in der Werbung stehen.
    supabase.from('quotes')
      .select('id', { count: 'exact', head: true })
      .eq('company_id', company.id)
      .gte('created_at', monatsStart),
  ])

  const plan = (firma?.plan ?? 'starter') === 'pro' ? 'pro' : 'starter'
  return {
    plan,
    laeuftBisISO: (firma?.plan_expires_at as string | null) ?? null,
    hatStripeKonto: Boolean(firma?.stripe_customer_id),
    angeboteDiesenMonat: count ?? 0,
    freikontingent: PRICING.freeAngeboteProMonat,
  }
}
