import Link from 'next/link'
import { Logo } from '@/components/Logo'

export const metadata = {
  title: 'Datenschutzerklärung – Sofortangebot',
}

export default function DatenschutzPage() {
  return (
    <div className="min-h-dvh bg-bg">
      <nav className="flex items-center justify-between px-6 py-5 border-b border-anthracite/8 bg-white">
        <Link href="/"><Logo variant="light" className="text-xl" /></Link>
      </nav>

      <div className="px-6 py-12 max-w-2xl mx-auto space-y-8">
        <h1 className="text-3xl font-black text-anthracite">Datenschutzerklärung</h1>

        {[
          {
            title: '1. Verantwortlicher',
            content: (
              <p>
                Verantwortlicher im Sinne der Datenschutz-Grundverordnung (DSGVO) ist:<br /><br />
                Sandra Holm<br />
                Wielandstr. 11<br />
                12159 Berlin<br />
                E-Mail: hallo@sofortangebot.app
              </p>
            ),
          },
          {
            title: '2. Erhobene Daten und Zwecke',
            content: (
              <div className="space-y-4">
                <div>
                  <strong className="font-black">Registrierung und Nutzerkonto</strong>
                  <p className="mt-1">Bei der Registrierung erheben wir E-Mail-Adresse und Passwort (verschlüsselt gespeichert). Rechtsgrundlage: Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung).</p>
                </div>
                <div>
                  <strong className="font-black">Betriebsdaten</strong>
                  <p className="mt-1">Im Rahmen der Nutzung speichern wir: Firmenname, Adresse, Steuernummer, IBAN, Gewerke-Angaben sowie erstellte Angebote mit Kundendaten. Diese Daten sind für die Vertragserfüllung notwendig. Rechtsgrundlage: Art. 6 Abs. 1 lit. b DSGVO.</p>
                </div>
                <div>
                  <strong className="font-black">Spracheingaben</strong>
                  <p className="mt-1">Aufgenommene Spracheingaben werden zur Transkription an OpenAI (Whisper) übermittelt. Die Audiodatei wird zusätzlich auf unseren Servern in der EU (Supabase, Frankfurt) gespeichert, damit Sie die Aufnahme erneut anhören und die Auswertung wiederholen können. Sie können jede Aufnahme in der App löschen; die Audiodatei wird dann unwiderruflich entfernt. Spätestens 30 Tage nach der Aufnahme löschen wir die Audiodatei automatisch. Transkript und die daraus erzeugten Positionen bleiben als Teil des Angebots erhalten. Rechtsgrundlage: Art. 6 Abs. 1 lit. b DSGVO.</p>
                </div>
                <div>
                  <strong className="font-black">Kundendaten</strong>
                  <p className="mt-1">Für Name, Adresse, E-Mail und Telefon der Kunden eines Handwerksbetriebs sind wir <strong className="font-black">nicht Verantwortlicher, sondern Auftragsverarbeiter</strong>. Verantwortlich ist der jeweilige Handwerksbetrieb: Er entscheidet über Zwecke und Mittel der Verarbeitung und über die Rechtsgrundlage. Wir verarbeiten diese Daten ausschließlich auf seine Weisung zur Angebotserstellung. Grundlage ist der <a href="/avv" className="text-signal-yellow underline">Auftragsverarbeitungsvertrag nach Art.&nbsp;28 DSGVO</a>. Wenn Sie Kunde eines Handwerksbetriebs sind und Auskunft oder Löschung Ihrer Daten wünschen, wenden Sie sich bitte an diesen Betrieb; erreicht uns eine solche Anfrage direkt, leiten wir sie unverzüglich dorthin weiter.</p>
                </div>
                <div>
                  <strong className="font-black">Server-Logs</strong>
                  <p className="mt-1">Beim Zugriff auf unsere Dienste werden technische Zugriffsdaten (IP-Adresse, Zeitstempel, aufgerufene URL) für maximal 7 Tage gespeichert. Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse an IT-Sicherheit).</p>
                </div>
              </div>
            ),
          },
          {
            title: '3. Auftragsverarbeiter',
            content: (
              <div className="space-y-4">
                <p>Wir setzen folgende Dienstleister als Auftragsverarbeiter ein. Mit allen wurde ein Auftragsverarbeitungsvertrag (AVV) gemäß Art. 28 DSGVO geschlossen oder ist durch AGB abgedeckt:</p>
                <div>
                  <strong className="font-black">Supabase Inc. (Datenbank &amp; Authentifizierung)</strong>
                  <p className="mt-1">Datenbankhosting auf Servern in der EU (Frankfurt). Supabase verarbeitet alle gespeicherten Nutzerdaten. Datenschutzrichtlinie: <a href="https://supabase.com/privacy" className="text-yellow underline" target="_blank" rel="noopener noreferrer">supabase.com/privacy</a></p>
                </div>
                <div>
                  <strong className="font-black">OpenAI, L.L.C. (Spracherkennung &amp; KI-Textverarbeitung)</strong>
                  <p className="mt-1">Spracheingaben werden zur Transkription (Whisper) und die daraus entstandenen Texte zur KI-gestützten Angebotserstellung (GPT) an OpenAI übermittelt. OpenAI verwendet über die Programmierschnittstelle übermittelte Daten nach eigener Zusage nicht zum Training seiner Modelle. Datenschutzrichtlinie: <a href="https://openai.com/policies/privacy-policy" className="text-yellow underline" target="_blank" rel="noopener noreferrer">openai.com/policies/privacy-policy</a></p>
                </div>
                <div>
                  <strong className="font-black">Resend Inc. (E-Mail-Versand)</strong>
                  <p className="mt-1">Beim Versand von Angeboten per E-Mail werden E-Mail-Adresse des Empfängers sowie der Angebotsinhalt an Resend übermittelt. Datenschutzrichtlinie: <a href="https://resend.com/privacy" className="text-yellow underline" target="_blank" rel="noopener noreferrer">resend.com/privacy</a></p>
                </div>
                <div>
                  <strong className="font-black">Stripe Payments Europe, Limited (Zahlungsabwicklung)</strong>
                  <p className="mt-1">Für Abonnement-Zahlungen nutzen wir Stripe. Zahlungsdaten werden direkt bei Stripe eingegeben und nicht von uns gespeichert. Datenschutzrichtlinie: <a href="https://stripe.com/privacy" className="text-yellow underline" target="_blank" rel="noopener noreferrer">stripe.com/privacy</a></p>
                </div>
                <div>
                  <strong className="font-black">Vercel Inc. (Hosting)</strong>
                  <p className="mt-1">Die Webanwendung wird auf Servern von Vercel gehostet. Datenschutzrichtlinie: <a href="https://vercel.com/legal/privacy-policy" className="text-yellow underline" target="_blank" rel="noopener noreferrer">vercel.com/legal/privacy-policy</a></p>
                </div>
                <div>
                  <strong className="font-black">Functional Software, Inc. dba Sentry (Fehlerprotokollierung)</strong>
                  <p className="mt-1">Zur Erkennung und Behebung technischer Fehler übermitteln wir Fehlerberichte an Sentry. Diese enthalten technische Angaben zum Fehler (Zeitpunkt, aufgerufene Funktion, Browser- und Geräteangaben, IP-Adresse) und können im Einzelfall Inhalte der gerade verarbeiteten Daten enthalten. Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse an einem lauffähigen und sicheren Dienst). Datenschutzrichtlinie: <a href="https://sentry.io/privacy/" className="text-yellow underline" target="_blank" rel="noopener noreferrer">sentry.io/privacy</a></p>
                </div>
              </div>
            ),
          },
          {
            title: '4. Drittland-Übermittlungen',
            content: (
              <p>
                OpenAI, Resend, Sentry und Vercel sind US-amerikanische Unternehmen; auch Supabase Inc. hat seinen Sitz in den USA, betreibt unsere Datenbank aber in der EU (Frankfurt). Wir unterscheiden ausdrücklich:<br /><br />
                <strong className="font-black">Vercel, Resend und Sentry</strong> sind unter dem EU-US Data Privacy Framework zertifiziert; die Übermittlung stützt sich auf den Angemessenheitsbeschluss der EU-Kommission (Art. 45 DSGVO).<br /><br />
                <strong className="font-black">OpenAI und Supabase</strong>: Die Übermittlung stützt sich auf die EU-Standardvertragsklauseln gemäß Art. 46 Abs. 2 lit. c DSGVO, ergänzt um vertragliche und technische Schutzmaßnahmen.<br /><br />
                <strong className="font-black">Stripe</strong>: Unser Vertragspartner ist Stripe Payments Europe, Limited mit Sitz in Irland — insoweit findet keine Drittlandübermittlung statt. Soweit Stripe Daten innerhalb der Unternehmensgruppe in die USA weitergibt, stützt sich dies auf die Zertifizierung unter dem EU-US Data Privacy Framework sowie ergänzend auf die EU-Standardvertragsklauseln.
              </p>
            ),
          },
          {
            title: '5. Cookies und lokale Speicherung',
            content: (
              <p>
                Wir verwenden ausschließlich technisch notwendige Cookies für die Authentifizierung (Session-Token). Diese Cookies sind für den Betrieb des Dienstes erforderlich und können nicht deaktiviert werden. Es werden keine Tracking-, Analyse- oder Werbe-Cookies eingesetzt. Eine Einwilligung nach § 25 Abs. 1 TDDDG ist für technisch notwendige Cookies nicht erforderlich (§ 25 Abs. 2 Nr. 2 TDDDG). Das TDDDG ist die seit dem 14.05.2024 geltende Bezeichnung des früheren TTDSG.
              </p>
            ),
          },
          {
            title: '6. Speicherdauer',
            content: (
              <div className="space-y-2">
                <p><strong className="font-black">Nutzerdaten:</strong> Bis zur Löschung des Accounts oder auf Anfrage.</p>
                <p><strong className="font-black">Angebote und Kundendaten:</strong> Bis zur Löschung durch den Nutzer oder Löschung des Accounts. Handelsrechtlich relevante Daten können bis zu 10 Jahre aufbewahrt werden (§ 257 HGB, § 147 AO).</p>
                <p><strong className="font-black">Zahlungsdaten bei Stripe:</strong> Gemäß gesetzlicher Aufbewahrungspflichten (bis zu 10 Jahre).</p>
                <p><strong className="font-black">Sprachaufnahmen (Audiodateien):</strong> Automatisch 30 Tage nach der Aufnahme, auf Wunsch des Nutzers jederzeit früher.</p>
                <p><strong className="font-black">Server-Logs:</strong> 7 Tage.</p>
              </div>
            ),
          },
          {
            title: '7. Betroffenenrechte',
            content: (
              <div className="space-y-2">
                <p>Sie haben das Recht auf:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li><strong>Auskunft</strong> über Ihre gespeicherten Daten (Art. 15 DSGVO)</li>
                  <li><strong>Berichtigung</strong> unrichtiger Daten (Art. 16 DSGVO)</li>
                  <li><strong>Löschung</strong> Ihrer Daten (Art. 17 DSGVO)</li>
                  <li><strong>Einschränkung</strong> der Verarbeitung (Art. 18 DSGVO)</li>
                  <li><strong>Datenübertragbarkeit</strong> (Art. 20 DSGVO)</li>
                  <li><strong>Widerspruch</strong> gegen die Verarbeitung (Art. 21 DSGVO)</li>
                </ul>
                <p className="mt-3">Zur Ausübung Ihrer Rechte wenden Sie sich an: <a href="mailto:hallo@sofortangebot.app" className="text-yellow underline">hallo@sofortangebot.app</a></p>
                <p>Sie haben zudem das Recht, sich bei einer Datenschutz-Aufsichtsbehörde zu beschweren. Zuständig für Berlin: <a href="https://www.datenschutz-berlin.de" className="text-yellow underline" target="_blank" rel="noopener noreferrer">Berliner Beauftragte für Datenschutz und Informationsfreiheit</a>.</p>
              </div>
            ),
          },
          {
            title: '8. Accountlöschung',
            content: (
              <p>
                Sie können Ihren Account jederzeit über die Einstellungen in der App oder per E-Mail löschen. Der Account wird sofort deaktiviert. Anschließend halten wir Ihre Daten noch 30 Tage vor, damit Sie sie exportieren oder den Account wiederherstellen können; danach werden alle mit Ihrem Account verbundenen Daten vollständig und unwiderruflich gelöscht — Angebote, Kundendaten, Sprachaufnahmen, Fotos und Ihr Zugang. Ausgenommen sind ausschließlich Daten, für die gesetzliche Aufbewahrungspflichten bestehen. Die Löschung können Sie über die Einstellungen in der App oder per E-Mail an <a href="mailto:hallo@sofortangebot.app" className="text-yellow underline">hallo@sofortangebot.app</a> beantragen.
              </p>
            ),
          },
          {
            title: '9. Aktualität dieser Datenschutzerklärung',
            content: (
              <p>
                Diese Datenschutzerklärung ist aktuell gültig und hat den Stand September 2026. Durch die Weiterentwicklung unserer Dienste oder aufgrund geänderter gesetzlicher bzw. behördlicher Vorgaben kann es notwendig werden, diese Datenschutzerklärung anzupassen. Die jeweils aktuelle Datenschutzerklärung ist unter dieser Adresse abrufbar.
              </p>
            ),
          },
        ].map(section => (
          <section key={section.title} className="bg-white rounded-2xl p-6 border border-anthracite/5">
            <h2 className="font-black text-anthracite text-lg mb-4">{section.title}</h2>
            <div className="text-anthracite/70 font-semibold text-sm leading-relaxed">
              {section.content}
            </div>
          </section>
        ))}
      </div>

      <footer className="border-t border-anthracite/8 px-6 py-6 flex items-center justify-between">
        <Logo variant="light" className="text-sm" />
        <div className="flex gap-4 text-anthracite/30 text-xs font-semibold">
          <Link href="/impressum">Impressum</Link>
          <Link href="/datenschutz" className="text-anthracite">Datenschutz</Link>
          <Link href="/agb">AGB</Link>
        </div>
      </footer>
    </div>
  )
}
