'use client'

import { motion } from 'framer-motion'

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
}

export function VorherNachherSection() {
  return (
    <section className="bg-white py-20 md:py-28">
      <div className="max-w-6xl mx-auto px-5 md:px-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{ visible: { transition: { staggerChildren: 0.12 } } }}
          className="grid md:grid-cols-2 gap-5 md:gap-6"
        >
          {/* VORHER */}
          <motion.div variants={fadeUp} className="bg-bg rounded-3xl p-8 md:p-10">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[20px]">🌙</span>
              <span className="text-red-400 text-[13px] font-extrabold font-syne tracking-widest uppercase">22:47 Uhr</span>
            </div>
            <div className="font-syne font-extrabold text-anthracite text-[22px] md:text-[26px] tracking-tight mb-8">Ohne Sofortangebot</div>
            <div className="flex flex-col gap-5">
              {[
                'Feierabend verschiebt sich — wieder Küchentisch',
                'Zettel vom Aufmaß suchen',
                'Flächen nachrechnen und hoffen, dass sie stimmen',
                'Angebot in Word tippen',
                'Zwei Tage später erst beim Kunden',
              ].map((t) => (
                <div key={t} className="flex items-start gap-4">
                  <span className="text-red-300 font-black text-sm mt-0.5 shrink-0 w-4">✕</span>
                  <span className="text-anthracite/45 text-sm leading-relaxed">{t}</span>
                </div>
              ))}
              <div className="flex items-start gap-4 pt-5 border-t border-anthracite/6">
                <span className="text-red-300 font-black text-sm mt-0.5 shrink-0 w-4">✕</span>
                <span className="text-anthracite/60 font-bold text-sm">Kunde wartet</span>
              </div>
            </div>
          </motion.div>

          {/* NACHHER */}
          <motion.div variants={fadeUp} className="bg-anthracite rounded-3xl p-8 md:p-10">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[20px]">☀️</span>
              <span className="text-yellow text-[13px] font-extrabold font-syne tracking-widest uppercase">17:03 Uhr</span>
            </div>
            <div className="font-syne font-extrabold text-white text-[22px] md:text-[26px] tracking-tight mb-8">Mit Sofortangebot</div>
            <div className="flex flex-col gap-5">
              {[
                'Aufmaß auf der Baustelle eingesprochen',
                'Flächen berechnet — mit Rechenweg, nicht geschätzt',
                'Kurz geprüft, Angebot fertig',
                'Kunde hat es, bevor du zu Hause bist',
              ].map((t) => (
                <div key={t} className="flex items-start gap-4">
                  <span className="text-yellow font-black text-sm mt-0.5 shrink-0 w-4">✓</span>
                  <span className="text-white/60 text-sm leading-relaxed">{t}</span>
                </div>
              ))}
              <div className="flex items-start gap-4 pt-5 border-t border-white/10">
                <span className="text-yellow font-black text-sm mt-0.5 shrink-0 w-4">✓</span>
                <span className="text-yellow font-bold text-sm">Feierabend 🍻</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
